package Enum;

public enum ETipoMensaje {
	SIMPLE,CONAVISORECEPCION,CONALERTASONIDO
}
